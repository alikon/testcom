<?php
/**
 * @package   Lorem
 * @copyright Copyright (c)2021 Alikon
 * @license   GNU General Public License version 3, or later
 */


defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

class plgConsoleLorem extends CMSPlugin
{
}