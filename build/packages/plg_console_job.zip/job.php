<?php
/**
 * @package   Job
 * @copyright Copyright (c)2021 Alikon
 * @license   GNU General Public License version 3, or later
 */


defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

class plgConsoleJob extends CMSPlugin
{
}